On linux need not to install anything but if you are using windows, python needs to be installed

--Open terminal

--Reach to project directory

--Run following command
python apontador.py

--It will ask you to enter file name, data will be saved in entered file which can be find in "imported_data" folder

--After entering file name it will ask to enter search URL, search on website and enter it,

Example :- http://www.apontador.com.br/local/search.html?q=S%C3%A3o+Jos%C3%A9+do+Rio+Preto&loc_z=S%C3%A3o+Paulo&loc=S%C3%A3o+Paulo%2C+SP&loc_y=S%C3%A3o+Paulo%2C+SP

It will start extracting data and process can be seen on terminal.


Point to remember
-Internect shoul be connected
-Website should up 
-URL should be correct
-Dont close terminal until script complete