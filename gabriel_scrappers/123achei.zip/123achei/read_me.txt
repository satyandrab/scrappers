Download zip folder, extract it at known location,

--Open terminal

--Reach to project directory

-- for adding categories, open file named as "categories.txt" and add more categories as listed already.

--Run following command
python 123achei.py

--It will ask you to enter file name, data will be saved in entered file which can be find in "imported_data" folder

--After entering file name it will pick category from file and start extracting data for mentioned categories.

Point to remember
-Internet should be connected
-Website should up and running
-URL should be correct
-Don't close terminal until script complete